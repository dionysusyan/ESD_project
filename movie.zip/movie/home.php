<!DOCTYPE html>
<html lang="en">

<head>
    <title>G2T3 Movie Homepage</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u"
        crossorigin="anonymous">
	
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/js/bootstrap.min.js"></script>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>ESD G2T3 | Movie Homepage</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">

    <!-- Font awesome -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">   
    <!-- slick slider -->
    <link rel="stylesheet" type="text/css" href="css/slick.css">
    <!-- price picker slider -->
    <link rel="stylesheet" type="text/css" href="css/nouislider.css">
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="css/jquery.fancybox.css" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="css/theme-color/bridge-theme.css" rel="stylesheet">     

    <!-- Main style sheet -->
    <link href="css/style.css" rel="stylesheet">    

    <!-- Google Font -->
    <link href='https://fonts.googleapis.com/css?family=Vollkorn' rel='stylesheet' type='text/css'>    
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body class="aa-price-range">  
  <!-- Pre Loader -->
  <div id="aa-preloader-area">
    <div class="pulse"></div>
  </div>
  <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"><i class="fa fa-angle-double-up"></i></a>
  <!-- END SCROLL TOP BUTTON -->
  
	<a class="navbar-brand aa-logo" href="home.php"> G2T3 <span> Movie2Go</span></a>
   </div>
  <!-- Start slider  -->
  <section id="aa-slider">
    <div class="aa-slider-area"> 
      <!-- Top slider -->
      <div class="aa-top-slider">
        <!-- Top slider single slide -->
        <div class="aa-top-slider-single">
          <img src="https://images3.alphacoders.com/651/651229.jpg" alt="img">
       
        </div>
        <!-- / Top slider single slide -->
        <!-- Top slider single slide -->
        <div class="aa-top-slider-single">
          <img src="img/slider/2.jpg" alt="img">
        </div>
        <!-- / Top slider single slide -->
        <!-- Top slider single slide -->
        <div class="aa-top-slider-single">
          <img src="img/slider/1.jpg" alt="img">
        </div>
        <!-- / Top slider single slide -->       
      </div>
    </div>
  </section>
  <!-- End slider  -->

  <!-- Advance Search -->
  <section id="aa-advance-search">
    <div class="container">
      <div class="aa-advance-search-area">
        <div class="form">
         <div class="aa-advance-search-top">
            <div class="row">
				<div class="col-md-10">
					<div class="aa-single-advance-search">
                    <div class="aa-search-btn">
						<form role="form" id="search-form">
						<input class="form-control" type="text" id="moviename" placeholder="Key In Movie Title Here">
					
                    </div>
					</div>
				</div>
					
				<div class="aa-single-submit">
                  <input id="please" type="submit">                    
                </div>	
					
				</form>
				
				<div id="results-header" class="text-center text-info"></div>
                <div id="results"></div>
				</div>
              </div>
              </div>
            </div>
          </div>
         </div>
        </div>
      </div>
  </section>
  <!-- / Advance Search -->
  
 <body>

    <div class="col-md-6">
        <table id="movieTable" class='table table-striped' id='movie-list' border='1'>
            <tr>
                <th>Cinema ID</th>
                <th>Movie Title</th>
                <th>Timing</th>
            </tr>
        </table>
    </div>
	
<script>

alert('#moviename');

$(function () {
	
            $("#search-form").submit(function (event) {
				alert("Hello! I am an alert box!!");
                var input = $('#moviename');
                $.post("http://10.211.55.5:8080/books"; + input, function (data) {
                    if (data.title == undefined) {
                        $("#results-header").html("<font color=red>The NRIC number you have entered is invalid or could not be found.<br><br></font>");
                        $("#results").html("");
                    } else {
                        // Placing the data within a table
                        var tableContent = 
                            "<table class='table' id='results-table'>"+
                                "<tr><td><b>NRIC</b></td><td>"      + data.isbn13 + "</td></tr>" +
                                "<tr><td><b>Name</td></br><td>"     + data.title + "</td></tr>" +
 
 
                            "</table>";
                        $("#results-header").html(" Results for Patient with NRIC No. " + document.getElementById('moviename').value);
                        $("#results").html(tableContent);
                    }
                }) // $.get()
                    .fail(function () {
                        $("#results-header").html("<font color=red>There is a problem in retrieving the information, please try again later.<br><br></font>");
                        $("#results").html("");
                    })
                // This prevents the submit button to continue it's default behaviour to submit so that the page doesn't refresh and stays here
                event.preventDefault();

            });
        });
	

	

    
</script>

  
  <!-- jQuery library -->
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
  <script src="js/jquery.min.js"></script>   
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.js"></script>   
  <!-- slick slider -->
  <script type="text/javascript" src="js/slick.js"></script>
  <!-- Price picker slider -->
  <script type="text/javascript" src="js/nouislider.js"></script>
   <!-- mixit slider -->
  <script type="text/javascript" src="js/jquery.mixitup.js"></script>
  <!-- Add fancyBox -->        
  <script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
  <!-- Custom js -->
  <script src="js/custom.js"></script> 

  </body>
</html>